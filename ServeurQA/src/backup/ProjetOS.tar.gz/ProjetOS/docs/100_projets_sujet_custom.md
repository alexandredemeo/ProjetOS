# Mini Projets - Sujets Customs

---

## Sujets Custom

!!! exemple ""
    - ^^Chat RZO^^ via des sockets : la première itération peut être **local only** et utiliser des ``pipes`` à la place des `socket`.  
    
    - ^^Créer une interface utilisateur (GUI) permettant de contrôler un programme en ligne de commande^^ (qui utilise donc stdin, stdout et stderr pour communiquer avec l'extérieur).   
      En effet, si on peut contrôler l'entrée (stdin) et la sortie (stdout, stderr) d'un programme en l'encapsulant dans un autre programme père, on peut tout faire avec !   
      Par exemple un wrapper graphique de commande bash complexes ?
