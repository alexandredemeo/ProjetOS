# Programmation Système : TP4 - E/S Bas Niveau

---

## Exercice 1 : Chaine vs. Int

Écrire un programme en C qui :  

- Ouvre (créer si n’existe pas) un fichier « test » , en lecture et écriture.
- Affiche son descripteur de fichier
- Y écrit une chaine de caractères ainsi qu’un entier
- Affiche la position du curseur de fichier
- Le replace au début du fichier
- Relis le fichier
- Ferme les descripteur proprement et se termine.