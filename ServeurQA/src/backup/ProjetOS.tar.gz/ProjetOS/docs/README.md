![CI/CD](https://github.com/jurocknsail/yncrea-cloudcomputing/workflows/CI/CD/badge.svg)

# About

Ce projet de développement a pour objectif la mise en place d'un système informatique client/serveur.

Merci de trouver le contenu sur  [Github Pages](https://github.com/alexandredemeo/ProjetOS/).
