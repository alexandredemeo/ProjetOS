#!/bin/bash

gnome-terminal --command="bash -c './client;$SHELL'"
clear
