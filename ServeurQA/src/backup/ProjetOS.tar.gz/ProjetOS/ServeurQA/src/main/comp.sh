#!/bin/bash

gcc client.c -o client
gcc serveur.c -o serveur

