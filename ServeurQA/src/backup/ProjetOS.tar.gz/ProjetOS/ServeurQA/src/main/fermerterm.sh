#!/bin/bash

client.sh && exit
